from selenium.webdriver.common.by import By


class WebLocators:

    def __init__(self):
        self.NameLocator = "xpath"
        self.BirthdayLocator = "xpath"
        self.searchbutton = "xpath"

    def enterText(self, driver, locator, textValue):
        driver.find_element(by=By.ID, value=locator).send_keys(textValue)

    def clickButton(self, driver, locator):
        driver.find_element(by=By.ID, value=locator).click()