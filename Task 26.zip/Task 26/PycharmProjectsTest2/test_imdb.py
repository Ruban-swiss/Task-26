import pytest
from Data import data
from Locator import locator

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains


class TestTask26:

    @pytest.fixture
    def boot(self):
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        yield
        self.driver.quit()

    def test_search(self, boot):
        try:
            self.driver.get(data.WebData().url) 
            self.driver.maximize_window()
            self.driver.implicitly_wait(10)
            action = ActionChains(self.driver)
            wait = WebDriverWait(self.driver, 20)

            for _ in range(9):  # used "for loop" to click "page down key" in keyboard, multiple times (To make name and birthdate textbox visible)
                action.send_keys(Keys.DOWN).perform()
            
            xpath = "/html/body/div[2]/main/div[2]/div[3]/section/section/div/section/section/div[2]/div/section/div[2]/div[1]/section/div/div[1]/div[1]/label/span[1]/div"
            self.driver.find_element(by=By.XPATH, value=xpath).click()
            xpath1 = "/html/body/div[2]/main/div[2]/div[3]/section/section/div/section/section/div[2]/div/section/div[2]/div[1]/section/div/div[1]/div[2]/div/div/div/div/div/div/input"
            wait.until(EC.presence_of_element_located((By.XPATH, xpath1))).send_keys("Ruban")

            for _ in range(9):  # used "for loop" to click "page down key" in keyboard, multiple times (To make name and birthdate textbox visible)
                action.send_keys(Keys.DOWN).perform()

            # Birthdate
            xpath = "/html/body/div[2]/main/div[2]/div[3]/section/section/div/section/section/div[2]/div/section/div[2]/div[1]/section/div/div[3]/div[1]/label/span[1]/div"
            self.driver.find_element(by=By.XPATH, value=xpath).click()
            xpath1 = "/html/body/div[2]/main/div[2]/div[3]/section/section/div/section/section/div[2]/div/section/div[2]/div[1]/section/div/div[3]/div[2]/div/div/div/div/div/div/input"
            wait.until(EC.presence_of_element_located((By.XPATH, xpath1))).send_keys("13-03-1979")

            # Search
            xpath = "/html/body/div[2]/main/div[2]/div[3]/section/section/div/section/section/div[2]/div/section/div[1]/button/span"
            self.driver.find_element(by=By.XPATH, value=xpath).click()

            expected_url = "https://www.imdb.com/search/name/?name=Ruban"
            assert expected_url == self.driver.current_url  # confirming whether url changed or not

            self.driver.find_element(by=By.XPATH, value=locator.WebLocators().NameLocator).send_keys(data.WebData().Name)
            self.driver.find_element(by=By.XPATH, value=locator.WebLocators().BirthdayLocator).send_keys(data.WebData().Birthday)
            self.driver.find_element(by=By.XPATH, value=locator.WebLocators().searchbutton).click()

            #locator.WebLocators().enterText(self.driver, locator.WebLocators().usernameLocator, data.WebData().username)
            #locator.WebLocators().enterText(self.driver, locator.WebLocators().passwordLocator, data.WebData().password)
            #locator.WebLocators().clickButton(self.driver, locator.WebLocators().buttonLocator)

            if self.driver.current_url == data.WebData().dashboardURL:
                print("Successfully LoggedIn")
        except NoSuchElementException as e:
            print("Error!", e)


# Run through "pytest" command in terminal, No need for calling functions below.
# obj = TestTask26()
# obj.test_search()
            