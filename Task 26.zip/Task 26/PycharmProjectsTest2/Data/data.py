class WebData:

    def __init__(self):
        self.url = "https://www.imdb.com/search/name/"
        self.Name = "Ruban"
        self.Birthday = "13-03-1979"
        self.search = "Search"
        self.dashboardURL = "https://www.imdb.com/search/name/"
